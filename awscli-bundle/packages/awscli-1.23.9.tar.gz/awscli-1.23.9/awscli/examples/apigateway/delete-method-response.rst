**To delete a method response for the given resource, method, and status code in an API**

Command::

  aws apigateway delete-method-response --rest-api-id 1234123412 --resource-id a1b2c3 --http-method GET --status-code 200
